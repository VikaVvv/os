const fs = require('fs').promises;
const path = require('path');

const DB_PATH = path.join(__dirname, 'db.json');

async function readData() {
  try {
    const data = await fs.readFile(DB_PATH, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    if (err.code === 'ENOENT') {
      await fs.writeFile(DB_PATH, JSON.stringify({ recordings: [] }, null, 2));
      return { recordings: [] };
    }
    throw err;
  }
}

async function writeData(data) {
  await fs.writeFile(DB_PATH, JSON.stringify(data, null, 2));
}

module.exports = {
  async getAll() {
    const data = await readData();
    return data.recordings;
  },

  async getById(id) {
    const data = await readData();
    const recording = data.recordings.find(r => r.id === id);
    if (!recording) throw new Error('Запись не найдена');
    return recording;
  },

  async add(recording) {
    const data = await readData();
    recording.id = Date.now().toString(); // Простой способ генерации ID
    data.recordings.push(recording);
    await writeData(data);
    return recording;
  },

  async update(id, updatedRecording) {
    const data = await readData();
    const index = data.recordings.findIndex(r => r.id === id);
    if (index === -1) throw new Error('Запись не найдена');
    
    data.recordings[index] = { ...data.recordings[index], ...updatedRecording };
    await writeData(data);
    return data.recordings[index];
  },

  async delete(id) {
    const data = await readData();
    const index = data.recordings.findIndex(r => r.id === id);
    if (index === -1) throw new Error('Запись не найдена');
    
    data.recordings.splice(index, 1);
    await writeData(data);
  }
};