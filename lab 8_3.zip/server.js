const express = require('express');
const bodyParser = require('body-parser');
const app = express();

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

const restRouter = require('./rest');
app.use('/', restRouter);

const PORT = process.env.PORT || 3005;
app.listen(PORT, () => {
  console.log(`Сервер запущен: http://localhost:${PORT}`);
});