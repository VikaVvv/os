const express = require('express');
const router = express.Router();
const store = require('./store');

router.get('/', (req, res) => {
  res.render('index');
});

router.get('/recordings', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = 5; // Number of items per page
    const searchQuery = req.query.search || '';
    const sortBy = req.query.sort || 'title-asc';
    
    let recordings = await store.getAll();
    
    // Apply search filter
    if (searchQuery) {
      recordings = recordings.filter(recording => 
        recording.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    // Apply sorting
    if (sortBy === 'title-asc') {
      recordings.sort((a, b) => a.title.localeCompare(b.title));
    } else if (sortBy === 'title-desc') {
      recordings.sort((a, b) => b.title.localeCompare(a.title));
    }
    
    // Pagination
    const totalItems = recordings.length;
    const totalPages = Math.ceil(totalItems / limit);
    const startIndex = (page - 1) * limit;
    const endIndex = Math.min(startIndex + limit, totalItems);
    const paginatedRecordings = recordings.slice(startIndex, endIndex);
    
    res.render('recordings', { 
      recordings: paginatedRecordings,
      currentPage: page,
      totalPages,
      searchQuery,
      sortBy
    });
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// ... rest of your existing routes ...

router.get('/recordings', async (req, res) => {
  try {
    const recordings = await store.getAll();
    res.render('recordings', { recordings });
  } catch (err) {
    res.status(500).send(err.message);
  }
});

router.get('/add', (req, res) => {
  res.render('add');
});

router.post('/recordings', async (req, res) => {
  try {
    await store.add(req.body);
    res.redirect('/recordings');
  } catch (err) {
    res.status(500).send(err.message);
  }
});

router.get('/edit/:id', async (req, res) => {
  try {
    const recording = await store.getById(req.params.id);
    res.render('edit', { recording });
  } catch (err) {
    res.status(500).send(err.message);
  }
});

router.post('/update/:id', async (req, res) => {
  try {
    await store.update(req.params.id, req.body);
    res.redirect('/recordings');
  } catch (err) {
    res.status(500).send(err.message);
  }
});

router.post('/delete/:id', async (req, res) => {
  try {
    await store.delete(req.params.id);
    res.redirect('/recordings');
  } catch (err) {
    res.status(500).send(err.message);
  }
});

module.exports = router;